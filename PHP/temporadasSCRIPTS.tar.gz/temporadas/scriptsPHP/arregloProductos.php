<?php	
		$productos[1]['clave']="F001";
		 $productos[1]['nombre']="Frappe de fresa";
		 $productos[1]['decripcion']="Bebida fria hecha de leche con fresa";
		 $productos[1]['categoria']="Frias";
		 $productos[1]['ingredientes']="Leche, yogurt, fresas, azucar";
		 $productos[1]['costo']=71;
		 $productos[1]['porcion']="vaso";
		 $productos[1]['imagen']="productos/frapeFresa.jpg"; //puedes hacer qu etome cierta carpeta desde la variable ya si abajo solo pones la carpeta que contiene a la carpeta que tienes aqui
		 $productos[1]['ventas']=10;
		 
		 $productos[2]['clave']="F002";
		 $productos[2]['nombre']="Frape Frapuccino";
		 $productos[2]['decripcion']="Bebida fria hecha de leche y cafe";
		 $productos[2]['categoria']="Frias";
		 $productos[2]['ingredientes']="Leche, cafe, hielo";
		 $productos[2]['costo']=250;
		 $productos[2]['porcion']="vaso";
		 $productos[2]['imagen']="productos/frapuccino.jpg"; //puedes hacer qu etome cierta carpeta desde la variable ya si abajo solo pones la carpeta que contiene a la carpeta que tienes aqui
		 $productos[2]['ventas']=50;
		 
		 $productos[3]['clave']="H001";
		 $productos[3]['nombre']="Americano";
		 $productos[3]['decripcion']="Cafe comun";
		 $productos[3]['categoria']="Calientes";
		 $productos[3]['ingredientes']="Agua, cafe, azucar";
		 $productos[3]['costo']=40;
		 $productos[3]['porcion']="taza";
		 $productos[3]['imagen']="productos/americano.jpg"; //puedes hacer qu etome cierta carpeta desde la variable ya si abajo solo pones la carpeta que contiene a la carpeta que tienes aqui
		 $productos[3]['ventas']=100;
		 
		 $productos[4]['clave']="C005";
		 $productos[4]['nombre']="Panini";
		 $productos[4]['decripcion']="Pan de diversos ingredientes";
		 $productos[4]['categoria']="Comida";
		 $productos[4]['ingredientes']="Pan, carne, verduras, aderezos";
		 $productos[4]['costo']=150;
		 $productos[4]['porcion']="Pieza";
		 $productos[4]['imagen']="productos/panini.jpg"; //puedes hacer qu etome cierta carpeta desde la variable ya si abajo solo pones la carpeta que contiene a la carpeta que tienes aqui
		 $productos[4]['ventas']=150;
		 
		 $productos[5]['clave']="P006";
		 $productos[5]['nombre']="Muffin";
		 $productos[5]['decripcion']="Pan con diferentes sabores";
		 $productos[5]['categoria']="Postres";
		 $productos[5]['ingredientes']="Pan, agregados";
		 $productos[5]['costo']=50;
		 $productos[5]['porcion']="Pieza";
		 $productos[5]['imagen']="productos/muffin.jpeg"; //puedes hacer qu etome cierta carpeta desde la variable ya si abajo solo pones la carpeta que contiene a la carpeta que tienes aqui
		 $productos[5]['ventas']=19;
		 
		 $productos[6]['clave']="H004";
		 $productos[6]['nombre']="Te";
		 $productos[6]['decripcion']="Infusiones";
		 $productos[6]['categoria']="Calientes";
		 $productos[6]['ingredientes']="Agua, infusion";
		 $productos[6]['costo']=70;
		 $productos[6]['porcion']="Vaso";
		 $productos[6]['imagen']="productos/te.jpeg"; //puedes hacer qu etome cierta carpeta desde la variable ya si abajo solo pones la carpeta que contiene a la carpeta que tienes aqui
		 $productos[6]['ventas']=130;
		 
		 

?>